import { test, expect } from '@playwright/test';
import { AuzmorLogin } from '../pages/AuzmorLogin';
import { Homepage} from '../pages/Homepage';
import { EventDetails } from '../pages/EventDetails';
const properties = require('properties-reader')('config.properties');
const url = properties.get('url');
const username = properties.get('username');
const password = properties.get('password');
const eventName = properties.get('eventname') 
const evenLocation = properties.get('eventlocation') 
const eventDescription = properties.get('eventdescription') 



test("Auzmor Login Test",async({page})=>{

    //Login Page
    const lgn=new AuzmorLogin(page);
    await lgn.gotoauzmor(url);
    await lgn.LmsLogin(username,password);

    //Home Page
    const home = new Homepage(page);
    await home.homepage();

    //Event Details Page
    const event=new EventDetails(page);
    await event.eventdetails(eventName,evenLocation,eventDescription);
    
    

})