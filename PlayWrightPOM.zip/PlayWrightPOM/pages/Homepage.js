exports.Homepage=class Homepage{

    constructor(page){
        this.page=page;
        this.clickTrainings=page.locator('xpath=//*[@data-testid="filter-by-training"]')
        this.clickEvents =  page.locator("xpath=//a[@data-testid='events-menu']")
        this.clickcreateevent = page.locator("xpath=//button[@data-testid='fab-btn' or @data-testid='create-course']")
    }

    async homepage(){
        await this.clickTrainings.click();
        await this.clickEvents.click();
        await this.clickcreateevent.click();
        await this.page.waitForTimeout(3000); 
    }

}