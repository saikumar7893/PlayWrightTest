const { expect } = require("@playwright/test");

exports.EventDetails=class EventDetails{
    constructor(page){
        this.page=page;
        this.eventname = page.locator("xpath=//input[@placeholder='Event Name']")
        this.eventtype = page.locator("xpath=//*[@data-testid='event-type-dropdown']")
        this.inpersonevent =  page.locator("xpath=//*[text()='In-Person']")
        this.eventlocation = page.locator("xpath=//input[@placeholder='Event Location']")
        this.eventcategory = page.locator("xpath=//*[text()='new']")
        this.description = page.locator("xpath=//*[@aria-label='rich-text-editor']")
        this.saveandcontinue = page.locator("xpath=//*[@data-testid='save-and-continue']")
        this.skipInstructor = page.locator("xpath=//*[@data-testid='skip-button']")
        this.skipAssesment = page.locator("xpath=//*[@aria-label='Skip Assessment']")
        this.skipCertificate = page.locator("//*[@data-testid='event-skip-certificate-btn']")
        this.savebutton = page.locator("xpath=//*[@data-testid='save-button']")
        this.clickpublish = page.locator("xpath=//*[@data-testid='publish-button']")
        this.assertion = page.locator("xpath=//div[@class='twelve wide column']//h1")



    }

    async eventdetails(eventName,descriptiondata,meetlocation){
        await this.eventname.fill(eventName);
        await this.eventtype.click();
        await this.inpersonevent.click();
        await this.eventlocation.fill(meetlocation);
        await this.eventcategory.click();
        await this.description.click();
        await this.description.fill(descriptiondata);
        await this.saveandcontinue.click();
        await this.skipInstructor.click(); 
        await this.skipAssesment.click();
        await this.page.waitForTimeout(3000); 
        await this.skipCertificate.click();
        await this.clickpublish.click();
        if(await this.assertion.innerText()==eventName){
            console.log("Event has been published")
        }
        else{
            console.log("Event was not yet published")
        }



    }
}