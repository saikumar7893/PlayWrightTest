exports.AuzmorLogin=class AuzmorLogin{


    constructor(page){
        this.page=page;
        this.auzmor_username = page.locator('xpath=//input[@placeholder="Enter your email address / username"]');
        this.auzmor_pwd = page.locator('xpath=//input[@placeholder="Enter your Password"]');
        this.auzmor_signin = page.locator('xpath=//button[@data-testid="login-submit-btn"]');
    }

    async gotoauzmor(url){
        
        await this.page.goto(url);
    }


    async LmsLogin(usrname,password){
        await this.auzmor_username.fill(usrname);
        await this.auzmor_pwd.fill(password);
        await this.auzmor_signin.click();

    }



}